#ifndef EXP_HPP_
#define EXP_HPP_


struct expresionstruct {
  string str ;
  vector<int> trues ;
  vector<int> falses ;
};

//declare struct for breaks and continues
struct breakContinueStruct {
  vector<int> breaks ;
  vector<int> continues ;
};

#endif /* EXP_HPP_ */
